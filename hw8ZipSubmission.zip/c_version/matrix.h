#ifndef MATRIX_H
#define MATRIX_H

#include <stdio.h> 

// Matrix structure
typedef struct {
    int rows;
    int cols;
    double *data; //Store data in a 1D array (row-major order)
} Matrix;


Matrix* create_matrix(int rows, int cols);
void destroy_matrix(Matrix* m);

void print_matrix(const Matrix* m, const char* name);
int set_matrix_element(Matrix* m, int row, int col, double value);
double get_matrix_element(const Matrix* m, int row, int col); // Add error checking
void fill_matrix_from_array(Matrix* m, const double* array_data);


Matrix* add_matrices(const Matrix* m1, const Matrix* m2);
Matrix* scalar_multiply_matrix(const Matrix* m, double scalar);
Matrix* transpose_matrix(const Matrix* m);
Matrix* multiply_matrices(const Matrix* m1, const Matrix* m2);

#endif 