#include "matrix.h"
#include <stdlib.h> //malloc, free
#include <stdio.h>  //printf, fprintf
#include <string.h> 

Matrix* create_matrix(int rows, int cols) {
    if (rows <= 0 || cols <= 0) {
        fprintf(stderr, "Error: Matrix dimensions must be positive.\n");
        return NULL;
    }
    Matrix *m = (Matrix*)malloc(sizeof(Matrix));
    if (m == NULL) {
        fprintf(stderr, "Couldn't allocate memory for Matrix struct.\n");
        return NULL;
    }
    m->rows = rows;
    m->cols = cols;
    m->data = (double*)malloc(rows * cols * sizeof(double));
    if (m->data == NULL) {
        fprintf(stderr, "Couldn't allocate memory for Matrix data.\n");
        free(m);
        return NULL;
    }
    for (int i = 0; i < rows * cols; i++) {
        m->data[i] = 0.0;
    }
    return m;
}

void destroy_matrix(Matrix* m) {
    if (m != NULL) {
        if (m->data != NULL) {
            free(m->data);
            m->data = NULL; 
        }
        free(m);
        m = NULL;
    }
}

void print_matrix(const Matrix* m, const char* name) {
    if (m == NULL || m->data == NULL) {
        printf("%s is NULL or data is NULL\n", name);
        return;
    }
    printf("Matrix %s (%d x %d):\n", name, m->rows, m->cols);
    for (int i = 0; i < m->rows; i++) {
        for (int j = 0; j < m->cols; j++) {
            printf("%8.2f ", m->data[i * m->cols + j]); 
        }
        printf("\n");
    }
    printf("\n");
}

int set_matrix_element(Matrix* m, int row, int col, double value) {
    if (m == NULL || m->data == NULL) return 0; // Indicate failure
    if (row < 0 || row >= m->rows || col < 0 || col >= m->cols) {
        fprintf(stderr, "Index out of bounds for set_matrix_element.\n");
        return 0;
    }
    m->data[row * m->cols + col] = value;
    return 1;
}

double get_matrix_element(const Matrix* m, int row, int col) {
    if (m == NULL || m->data == NULL || row < 0 || row >= m->rows || col < 0 || col >= m->cols) {
        fprintf(stderr, "Index out of bounds for get_matrix_element. Returning 0.0.\n");
        return 0.0; 
    }
    return m->data[row * m->cols + col];
}

void fill_matrix_from_array(Matrix* m, const double* array_data) {
    if (m == NULL || m->data == NULL || array_data == NULL) return;

    for (int i = 0; i < m->rows * m->cols; i++) {
        m->data[i] = array_data[i];
    }
}


Matrix* add_matrices(const Matrix* m1, const Matrix* m2) {
    if (m1 == NULL || m2 == NULL) {
        fprintf(stderr, "One or both matrices are NULL for addition.\n");
        return NULL;
    }
    if (m1->rows != m2->rows || m1->cols != m2->cols) {
        fprintf(stderr, "Matrices dimensions do not match for addition.\n");
        return NULL;
    }
    Matrix* result = create_matrix(m1->rows, m1->cols);
    if (result == NULL) return NULL;

    for (int i = 0; i < m1->rows * m1->cols; i++) {
        result->data[i] = m1->data[i] + m2->data[i];
    }
    return result;
}

Matrix* scalar_multiply_matrix(const Matrix* m, double scalar) {
    if (m == NULL) {
        fprintf(stderr, "Matrix is NULL for scalar multiplication.\n");
        return NULL;
    }
    Matrix* result = create_matrix(m->rows, m->cols);
    if (result == NULL) return NULL;

    for (int i = 0; i < m->rows * m->cols; i++) {
        result->data[i] = m->data[i] * scalar;
    }
    return result;
}

Matrix* transpose_matrix(const Matrix* m) {
    if (m == NULL) {
        fprintf(stderr, "Matrix is NULL for transpose.\n");
        return NULL;
    }
    Matrix* result = create_matrix(m->cols, m->rows); //dimensions get swapped
    if (result == NULL) return NULL; 

    for (int i = 0; i < m->rows; i++) {
        for (int j = 0; j < m->cols; j++) {
            result->data[j * result->cols + i] = m->data[i * m->cols + j];
        }
    }
    return result;
}

Matrix* multiply_matrices(const Matrix* m1, const Matrix* m2) {
    if (m1 == NULL || m2 == NULL) {
        fprintf(stderr, "One or both matrices are NULL for multiplication.\n");
        return NULL;
    }
    if (m1->cols != m2->rows) {
        fprintf(stderr, "Matrices dimensions are incompatible for multiplication (m1->cols != m2->rows).\n");
        return NULL;
    }
    Matrix* result = create_matrix(m1->rows, m2->cols);
    if (result == NULL) return NULL;

    for (int i = 0; i < m1->rows; ++i) {
        for (int j = 0; j < m2->cols; ++j) {
            double sum = 0.0;
            for (int k = 0; k < m1->cols; ++k) { 
                sum += m1->data[i * m1->cols + k] * m2->data[k * m2->cols + j];
            }
            result->data[i * result->cols + j] = sum;
        }
    }
    return result;
}