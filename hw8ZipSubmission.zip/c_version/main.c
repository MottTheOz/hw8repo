#include "matrix.h"
#include <stdio.h>

int main() {
    double a_vals[] = {6, 4, 8, 3};
    double b_vals[] = {1, 2, 3, 4, 5, 6};
    double c_vals[] = {2, 4, 6, 1, 3, 5};

    Matrix *A = create_matrix(2, 2);
    fill_matrix_from_array(A, a_vals);
    Matrix *B = create_matrix(2, 3);
    fill_matrix_from_array(B, b_vals);
    Matrix *C = create_matrix(2, 3);
    fill_matrix_from_array(C, c_vals);

    print_matrix(A, "A");
    print_matrix(B, "B");
    print_matrix(C, "C");


    Matrix *M1 = scalar_multiply_matrix(B, 3.0);
    if (!M1) { printf("Failed to calculate 3*B\n"); return 1; }
    print_matrix(M1, "M1 = 3*B");


    Matrix *M2 = transpose_matrix(C);
    if (!M2) { printf("Failed to calculate C_transpose\n"); destroy_matrix(M1); return 1; }
    print_matrix(M2, "M2 = C^T");

   
    Matrix *M3 = multiply_matrices(M1, M2);
    if (!M3) { printf("Failed to calculate M1*M2\n"); destroy_matrix(M1); destroy_matrix(M2); return 1; }
    print_matrix(M3, "M3 = M1 * M2");

    
    Matrix *D = add_matrices(A, M3);
    if (!D) { printf("Failed to calculate A+M3\n"); destroy_matrix(M1); destroy_matrix(M2); destroy_matrix(M3); return 1; }
    print_matrix(D, "D = A + M3");
    
    printf("Expected D:\n 90.00  70.00\n200.00 150.00\n\n");

 
    destroy_matrix(A);
    destroy_matrix(B);
    destroy_matrix(C);
    destroy_matrix(M1);
    destroy_matrix(M2);
    destroy_matrix(M3);
    destroy_matrix(D);

    return 0;
}