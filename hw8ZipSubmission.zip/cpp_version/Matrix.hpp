#ifndef MATRIX_HPP
#define MATRIX_HPP

#include <vector>
#include <iostream>
#include <stdexcept> 
#include <iomanip>  

class Matrix {
private:
    int num_rows;
    int num_cols;
    std::vector<std::vector<double>> data;

public:
    Matrix(int rows, int cols);
    Matrix(const std::vector<std::vector<double>>& init_data);


    int getRows() const { return num_rows; }
    int getCols() const { return num_cols; }


    double& operator()(int r, int c);            
    const double& operator()(int r, int c) const; 

    Matrix operator+(const Matrix& other) const;
    Matrix operator*(double scalar) const;        
    Matrix operator*(const Matrix& other) const;  

    Matrix transpose() const;


    friend Matrix operator*(double scalar, const Matrix& m);


    friend std::ostream& operator<<(std::ostream& os, const Matrix& m);
};

#endif 