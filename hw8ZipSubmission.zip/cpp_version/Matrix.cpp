#include "Matrix.hpp"

Matrix::Matrix(int rows, int cols) : num_rows(rows), num_cols(cols) {
    if (rows <= 0 || cols <= 0) {
        throw std::invalid_argument("Matrix dimensions must be positive.");
    }
    data.resize(num_rows, std::vector<double>(num_cols, 0.0));
}

Matrix::Matrix(const std::vector<std::vector<double>>& init_data) {
    if (init_data.empty() || init_data[0].empty()) {
        throw std::invalid_argument("Initialization data cannot be empty.");
    }
    num_rows = init_data.size();
    num_cols = init_data[0].size();
    for (const auto& row_vec : init_data) {
        if (row_vec.size() != static_cast<size_t>(num_cols)) {
            throw std::invalid_argument("Initialization data has inconsistent column counts (ragged array).");
        }
    }
    data = init_data;
}


double& Matrix::operator()(int r, int c) {
    if (r < 0 || r >= num_rows || c < 0 || c >= num_cols) {
        throw std::out_of_range("Matrix subscript out of bounds.");
    }
    return data[r][c];
}

const double& Matrix::operator()(int r, int c) const {
    if (r < 0 || r >= num_rows || c < 0 || c >= num_cols) {
        throw std::out_of_range("Matrix subscript out of bounds.");
    }
    return data[r][c];
}

Matrix Matrix::operator+(const Matrix& other) const {
    if (num_rows != other.num_rows || num_cols != other.num_cols) {
        throw std::invalid_argument("Matrices have incompatible dimensions for addition.");
    }
    Matrix result(num_rows, num_cols);
    for (int i = 0; i < num_rows; i++) {
        for (int j = 0; j < num_cols; j++) {
            result.data[i][j] = data[i][j] + other.data[i][j];
        }
    }
    return result;
}

Matrix Matrix::operator*(double scalar) const {
    Matrix result(num_rows, num_cols);
    for (int i = 0; i < num_rows; i++) {
        for (int j = 0; j < num_cols; j++) {
            result.data[i][j] = data[i][j] * scalar;
        }
    }
    return result;
}


Matrix operator*(double scalar, const Matrix& m) {
    return m * scalar; 
}

Matrix Matrix::transpose() const {
    Matrix result(num_cols, num_rows); 
    for (int i = 0; i < num_rows; i++) {
        for (int j = 0; j < num_cols; j++) {
            result.data[j][i] = data[i][j];
        }
    }
    return result;
}

Matrix Matrix::operator*(const Matrix& other) const {
    if (num_cols != other.num_rows) {
        throw std::invalid_argument("Matrices have incompatible dimensions for multiplication (this->cols != other.rows).");
    }
    Matrix result(num_rows, other.num_cols);
    for (int i = 0; i < num_rows; i++) {
        for (int j = 0; j < other.num_cols; j++) {
            double sum = 0.0;
            for (int k = 0; k < num_cols; k++) { // Or other.num_rows
                sum += data[i][k] * other.data[k][j];
            }
            result.data[i][j] = sum;
        }
    }
    return result;
}

// Friend function for output streaming
std::ostream& operator<<(std::ostream& os, const Matrix& m) {
    os << "Matrix (" << m.num_rows << " x " << m.num_cols << "):\n";
    for (int i = 0; i < m.num_rows; i++) {
        for (int j = 0; j < m.num_cols; j++) {
            os << std::fixed << std::setprecision(2) << std::setw(8) << m.data[i][j] << " ";
        }
        os << "\n";
    }
    return os;
}