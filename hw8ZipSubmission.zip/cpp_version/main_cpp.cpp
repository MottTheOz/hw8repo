#include "Matrix.hpp"
#include <iostream>
#include <vector>

int main() {
    try {
        Matrix A({{6, 4}, {8, 3}});
        Matrix B({{1, 2, 3}, {4, 5, 6}});
        Matrix C({{2, 4, 6}, {1, 3, 5}});

        std::cout << A << std::endl;
        std::cout << B << std::endl;
        std::cout << C << std::endl;

        Matrix M1 = 3.0 * B; 

        Matrix M2 = C.transpose();
        std::cout << "M2 = C_transpose:\n" << M2 << std::endl;


        Matrix M3 = M1 * M2; 
        std::cout << "M3 = M1 * M2:\n" << M3 << std::endl;


        Matrix D = A + M3; 
        std::cout << "D = A + M3:\n" << D << std::endl;

        std::cout << "Expected D:\n 90.00  70.00\n200.00 150.00\n\n" << std::endl;


    } catch (const std::exception& e) {
        std::cerr << "An error occurred: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}